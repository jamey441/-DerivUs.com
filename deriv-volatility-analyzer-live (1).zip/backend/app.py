
from flask import Flask, jsonify
from flask_cors import CORS
import threading
import requests
import json
import time
from websocket import create_connection

app = Flask(__name__)
CORS(app)

TELEGRAM_BOT_TOKEN = "8270312163:AAE0m80qBTn2CRfZY_cmHNnWFq_dSvHUQ2g"
TELEGRAM_CHAT_ID = "6190782506"

live_data = {
    "V75": {
        "prices": [],
        "timestamps": [],
        "rsi": 0,
        "signal": "Hold",
    }
}

def send_telegram_alert(message):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {"chat_id": TELEGRAM_CHAT_ID, "text": message}
    try:
        requests.post(url, data=payload)
    except Exception as e:
        print("Telegram error:", e)

def calculate_rsi(prices, period=14):
    if len(prices) < period + 1:
        return 50
    gains, losses = 0, 0
    for i in range(-period, -1):
        diff = prices[i + 1] - prices[i]
        if diff > 0:
            gains += diff
        else:
            losses -= diff
    avg_gain = gains / period
    avg_loss = losses / period
    rs = avg_gain / (avg_loss or 1)
    return 100 - 100 / (1 + rs)

def deriv_ws_listener():
    ws = create_connection("wss://ws.binaryws.com/websockets/v3?app_id=1089")
    ws.send(json.dumps({"ticks": "R_75", "subscribe": 1}))
    
    while True:
        try:
            response = json.loads(ws.recv())
            if "tick" in response:
                price = float(response["tick"]["quote"])
                timestamp = time.strftime('%H:%M:%S', time.gmtime(response["tick"]["epoch"]))
                data = live_data["V75"]

                data["prices"].append(price)
                data["timestamps"].append(timestamp)

                if len(data["prices"]) > 30:
                    data["prices"] = data["prices"][-30:]
                    data["timestamps"] = data["timestamps"][-30:]

                rsi = calculate_rsi(data["prices"])
                signal = "Hold"
                if rsi < 30:
                    signal = "Buy"
                elif rsi > 70:
                    signal = "Sell"

                if signal != data["signal"] and signal in ["Buy", "Sell"]:
                    send_telegram_alert(f"Live Signal: {signal} on V75 (RSI: {rsi:.2f})")

                data["rsi"] = round(rsi, 2)
                data["signal"] = signal

        except Exception as e:
            print("WebSocket error:", e)
            time.sleep(5)
            try:
                ws = create_connection("wss://ws.binaryws.com/websockets/v3?app_id=1089")
                ws.send(json.dumps({"ticks": "R_75", "subscribe": 1}))
            except:
                continue

@app.route("/api/volatility/V75")
def get_live_v75():
    return jsonify(live_data["V75"])

if __name__ == "__main__":
    threading.Thread(target=deriv_ws_listener, daemon=True).start()
    app.run(debug=True, port=5000)
